local function startProtectedSystem()
    outputDebugString("[TEST RESOURCE] Sistema iniciado correctamente.", 3)
    setElementData(resourceRoot, "cs:testResourceRunning", true)
end

addEventHandler("onResourceStart", resourceRoot, function()
    outputDebugString("[TEST RESOURCE] Recurso arrancando...", 3)

    -- Este archivo está hecho para que tu web le inyecte automáticamente
    -- el bloque de validación de licencia aquí.

    -- Si la web todavía no ha inyectado nada, igual arranca para pruebas básicas.
    if not ConfigLicense or type(ConfigLicense) ~= "table" then
        outputDebugString("[TEST RESOURCE] No existe ConfigLicense.", 1)
        return
    end

    outputDebugString("[TEST RESOURCE] License detectada: " .. tostring(ConfigLicense.license or "nil"), 3)

    -- Marcador para que la web inserte aquí la lógica de validación
    -- [CS_LICENSE_INJECT_HERE]

    startProtectedSystem()
end)
