local calls = {}      -- [id] = {id, fromName, fromId, category, message, status, staffName}
local nextId = 1

-- CONFIG: define quién es staff (ACL group)
local STAFF_ACL = "Staff"

local function isStaff(plr)
  if not isElement(plr) then return false end
  local acc = getPlayerAccount(plr)
  if not acc or isGuestAccount(acc) then return false end
  local accName = getAccountName(acc)
  local group = aclGetGroup(STAFF_ACL)
  if not group then return false end
  return isObjectInACLGroup("user." .. accName, group)
end

local function playerId(plr)
  return getElementData(plr, "ID") or getElementData(plr, "id") or getPlayerSerial(plr):sub(1, 8)
end

local function statusToClient(plr, ok, msg)
  triggerClientEvent(plr, "sc:status", plr, ok, msg)
end

local function syncToStaff(plr)
  if not isStaff(plr) then return end

  local list = {}
  for _, c in pairs(calls) do
    list[#list+1] = {
      id = c.id,
      fromName = c.fromName,
      fromId = c.fromId,
      category = c.category,
      message = c.message,
      status = c.status,        -- "pending"|"accepted"|"rejected"
      staffName = c.staffName or ""
    }
  end

  table.sort(list, function(a,b) return a.id > b.id end)
  triggerClientEvent(plr, "sc:sync", plr, list)
end

addEvent("sc:requestSync", true)
addEventHandler("sc:requestSync", root, function()
  local plr = client
  syncToStaff(plr)
end)

addEvent("sc:createCall", true)
addEventHandler("sc:createCall", root, function(category, msg)
  local plr = client
  category = tostring(category or "General")
  msg = tostring(msg or "")

  if msg:gsub("%s+", "") == "" then
    return statusToClient(plr, false, "Escribe un mensaje para el staff.")
  end

  local id = nextId
  nextId = nextId + 1

  calls[id] = {
    id = id,
    fromName = getPlayerName(plr),
    fromId = tostring(playerId(plr)),
    category = category:sub(1, 32),
    message = msg:sub(1, 120),
    status = "pending",
    staffName = nil,
    fromPlayer = plr
  }

  statusToClient(plr, true, "✅ Llamado enviado. Espera respuesta del staff.")

  -- Avisar a todo staff
  for _, p in ipairs(getElementsByType("player")) do
    if isStaff(p) then
      triggerClientEvent(p, "sc:newCall", p)
      outputChatBox(("📞 Nuevo llamado #%d de %s"):format(id, getPlayerName(plr)), p, 180, 220, 255, true)
    end
  end
end)

addEvent("sc:acceptCall", true)
addEventHandler("sc:acceptCall", root, function(id)
  local staff = client
  if not isStaff(staff) then
    return statusToClient(staff, false, "No tienes permisos de staff.")
  end

  id = tonumber(id) or 0
  local c = calls[id]
  if not c then
    return statusToClient(staff, false, "Ese llamado no existe.")
  end
  if c.status ~= "pending" then
    return statusToClient(staff, false, "Ese llamado ya fue atendido.")
  end

  c.status = "accepted"
  c.staffName = getPlayerName(staff)

  statusToClient(staff, true, ("✅ Aceptaste el llamado #%d"):format(id))

  if isElement(c.fromPlayer) then
    statusToClient(c.fromPlayer, true, ("👮 Tu llamado #%d fue aceptado por %s"):format(id, c.staffName))
  end

  -- Resync a todos los staff
  for _, p in ipairs(getElementsByType("player")) do
    if isStaff(p) then
      syncToStaff(p)
    end
  end
end)

addEvent("sc:rejectCall", true)
addEventHandler("sc:rejectCall", root, function(id)
  local staff = client
  if not isStaff(staff) then
    return statusToClient(staff, false, "No tienes permisos de staff.")
  end

  id = tonumber(id) or 0
  local c = calls[id]
  if not c then
    return statusToClient(staff, false, "Ese llamado no existe.")
  end
  if c.status ~= "pending" then
    return statusToClient(staff, false, "Ese llamado ya fue atendido.")
  end

  c.status = "rejected"
  c.staffName = getPlayerName(staff)

  statusToClient(staff, true, ("🚫 Rechazaste el llamado #%d"):format(id))

  if isElement(c.fromPlayer) then
    statusToClient(c.fromPlayer, false, ("❌ Tu llamado #%d fue rechazado por %s"):format(id, c.staffName))
  end

  for _, p in ipairs(getElementsByType("player")) do
    if isStaff(p) then
      syncToStaff(p)
    end
  end
end)
