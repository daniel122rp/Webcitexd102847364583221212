let selectedId = null;
let calls = [];

const listEl = document.getElementById("list");
const acceptBtn = document.getElementById("acceptBtn");
const rejectBtn = document.getElementById("rejectBtn");
const closeBtn  = document.getElementById("closeBtn");
const toastEl   = document.getElementById("toast");

function nav(action, extra = {}) {
  const params = new URLSearchParams({ action, ...extra });
  window.location = `mta://sc?${params.toString()}`;
}

closeBtn.onclick = () => nav("close");

acceptBtn.onclick = () => {
  if (!selectedId) return;
  nav("accept", { id: selectedId });
};

rejectBtn.onclick = () => {
  if (!selectedId) return;
  nav("reject", { id: selectedId });
};

function statusClass(st) {
  if (st === "accepted") return "accepted";
  if (st === "rejected") return "rejected";
  return "pending";
}

function statusLabel(st, staffName) {
  if (st === "accepted") return `ACEPTADO${staffName ? " • " + staffName : ""}`;
  if (st === "rejected") return `RECHAZADO${staffName ? " • " + staffName : ""}`;
  return "PENDIENTE";
}

function render() {
  listEl.innerHTML = "";
  if (!calls.length) {
    listEl.innerHTML = `<div class="row" style="grid-template-columns:1fr;">
      <div class="small" style="opacity:.8;">No hay llamados ahora mismo.</div>
    </div>`;
    selectedId = null;
    acceptBtn.disabled = true;
    rejectBtn.disabled = true;
    return;
  }

  calls.forEach(c => {
    const row = document.createElement("div");
    row.className = "row";
    row.style.cursor = "pointer";
    row.style.background = (selectedId === c.id) ? "rgba(60,120,255,0.10)" : "rgba(255,255,255,0.03)";

    row.innerHTML = `
      <div class="badge">⬆ ${escapeHtml(c.fromName)} <span class="small">(${escapeHtml(String(c.fromId))})</span></div>
      <div class="small">${escapeHtml(c.category || "General")}</div>
      <div class="msg">${escapeHtml(c.message || "")}</div>
      <div class="status ${statusClass(c.status)}">${escapeHtml(statusLabel(c.status, c.staffName))}</div>
    `;

    row.onclick = () => {
      selectedId = c.id;
      acceptBtn.disabled = (c.status !== "pending");
      rejectBtn.disabled = (c.status !== "pending");
      render();
    };

    listEl.appendChild(row);
  });
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}

// Lua llama esto
window.setCalls = function(newCalls) {
  calls = Array.isArray(newCalls) ? newCalls : [];
  if (selectedId && !calls.some(x => x.id === selectedId)) selectedId = null;

  const sel = calls.find(x => x.id === selectedId);
  acceptBtn.disabled = !(sel && sel.status === "pending");
  rejectBtn.disabled = !(sel && sel.status === "pending");

  render();
};

// Toast (Lua llama esto)
window.setStatus = function(msg, ok) {
  toastEl.textContent = msg || "";
  toastEl.className = "toast show " + (ok ? "ok" : "err");
  clearTimeout(window.__t);
  window.__t = setTimeout(() => {
    toastEl.className = "toast";
  }, 2200);
};
