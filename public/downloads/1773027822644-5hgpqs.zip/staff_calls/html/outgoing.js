const closeBtn  = document.getElementById("closeBtn");
const cancelBtn = document.getElementById("cancelBtn");
const sendBtn   = document.getElementById("sendBtn");
const catEl     = document.getElementById("cat");
const msgEl     = document.getElementById("msg");
const countEl   = document.getElementById("count");
const toastEl   = document.getElementById("toast");

function nav(action, extra = {}) {
  const params = new URLSearchParams({ action, ...extra });
  window.location = `mta://sc?${params.toString()}`;
}

closeBtn.onclick = () => nav("close");
cancelBtn.onclick = () => nav("close");

msgEl.addEventListener("input", () => {
  countEl.textContent = `${(msgEl.value || "").length}/120`;
});

sendBtn.onclick = () => {
  const cat = (catEl.value || "General").trim();
  const msg = (msgEl.value || "").trim();
  if (!msg) return window.setStatus("Escribe un mensaje.", false);

  nav("send", {
    cat: encodeURIComponent(cat),
    msg: encodeURIComponent(msg)
  });
};

// Lua llama esto
window.setStatus = function(msg, ok) {
  toastEl.textContent = msg || "";
  toastEl.className = "toast show " + (ok ? "ok" : "err");
  clearTimeout(window.__t);
  window.__t = setTimeout(() => {
    toastEl.className = "toast";
  }, 2200);

  if (ok) {
    msgEl.value = "";
    countEl.textContent = "0/120";
  }
};
