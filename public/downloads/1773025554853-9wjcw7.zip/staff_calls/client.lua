local sx, sy = guiGetScreenSize()

local UI = {
  browser = nil,
  page = nil, -- "incoming" | "outgoing"
  open = false
}

local function renderBrowser()
  if UI.open and isElement(UI.browser) then
    dxDrawImage(0, 0, sx, sy, UI.browser, 0, 0, 0, tocolor(255,255,255,255), true)
  end
end

local function setUIState(state)
  UI.open = state
  showCursor(state)
  guiSetInputEnabled(state)

  -- Bloquea controles mientras UI abierta (puedes ajustar)
  toggleAllControls(not state, true, true)

  if state then
    addEventHandler("onClientRender", root, renderBrowser)
    if isElement(UI.browser) then
      focusBrowser(UI.browser)
    end
  else
    removeEventHandler("onClientRender", root, renderBrowser)
  end
end

local function openUI(page)
  if UI.open then return end
  UI.page = page

  UI.browser = createBrowser(sx, sy, true, true) -- local, transparent
  addEventHandler("onClientBrowserCreated", UI.browser, function()
    local url = (page == "incoming")
      and "http://mta/local/html/incoming.html"
      or "http://mta/local/html/outgoing.html"

    loadBrowserURL(UI.browser, url)
    focusBrowser(UI.browser)
  end)

  setUIState(true)
end

local function closeUI()
  if not UI.open then return end
  setUIState(false)

  if isElement(UI.browser) then
    destroyElement(UI.browser)
  end
  UI.browser = nil
  UI.page = nil
end

-- Comandos
addCommandHandler("llamados", function()
  openUI("incoming")
  triggerServerEvent("sc:requestSync", localPlayer)
end)

addCommandHandler("llamarstaff", function()
  openUI("outgoing")
end)

-- Bridge: captura mta://sc?... desde CEF
addEventHandler("onClientBrowserNavigate", root, function(url)
  if not UI.open then return end
  if type(url) ~= "string" then return end
  if url:sub(1, 8) ~= "mta://sc" then return end

  cancelEvent()

  local function urldecode(s)
    s = tostring(s or "")
    s = s:gsub("+", " ")
    s = s:gsub("%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end)
    return s
  end

  local function getParam(key)
    local v = url:match(key .. "=([^&]+)")
    return urldecode(v or "")
  end

  local action = getParam("action")

  if action == "close" then
    closeUI()
    return
  end

  if action == "send" then
    local category = urldecode(getParam("cat"))
    local msg = urldecode(getParam("msg"))
    triggerServerEvent("sc:createCall", localPlayer, category, msg)
    return
  end

  if action == "accept" then
    local id = tonumber(getParam("id")) or 0
    triggerServerEvent("sc:acceptCall", localPlayer, id)
    return
  end

  if action == "reject" then
    local id = tonumber(getParam("id")) or 0
    triggerServerEvent("sc:rejectCall", localPlayer, id)
    return
  end
end)

-- Server -> CEF: actualizar lista (panel entrantes)
addEvent("sc:sync", true)
addEventHandler("sc:sync", root, function(calls)
  if not UI.open or UI.page ~= "incoming" then return end
  if not isElement(UI.browser) then return end

  local json = toJSON(calls or {}, true)
  executeBrowserJavascript(UI.browser, ("window.setCalls(%s);"):format(json))
end)

-- Server -> Client: toast/estado (ambos paneles)
addEvent("sc:status", true)
addEventHandler("sc:status", root, function(ok, msg)
  msg = tostring(msg or "")
  ok = ok and true or false

  if UI.open and isElement(UI.browser) then
    executeBrowserJavascript(UI.browser, ("window.setStatus(%q,%s);"):format(msg, ok and "true" or "false"))
  else
    outputChatBox(msg)
  end
end)

-- Llamado nuevo: si el staff tiene UI abierta, refrescamos
addEvent("sc:newCall", true)
addEventHandler("sc:newCall", root, function()
  if UI.open and UI.page == "incoming" then
    triggerServerEvent("sc:requestSync", localPlayer)
  end
end)
