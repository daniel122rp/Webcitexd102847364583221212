addEventHandler("onClientResourceStart", resourceRoot, function()
    outputChatBox("#00ff99[TEST RESOURCE] #ffffffEl recurso de prueba cargó en cliente.", 255, 255, 255, true)
end)
