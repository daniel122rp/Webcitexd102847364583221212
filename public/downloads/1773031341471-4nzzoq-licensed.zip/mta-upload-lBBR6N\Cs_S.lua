local function startProtectedSystem()
    outputDebugString("[TEST RESOURCE] Sistema iniciado correctamente.", 3)
    setElementData(resourceRoot, "cs:testResourceRunning", true)
end

addEventHandler("onResourceStart", resourceRoot, function()
    outputDebugString("[TEST RESOURCE] Recurso arrancando...", 3)

    -- Este archivo está hecho para que tu web le inyecte automáticamente
    -- el bloque de validación de licencia aquí.

    -- Si la web todavía no ha inyectado nada, igual arranca para pruebas básicas.
    if not ConfigLicense or type(ConfigLicense) ~= "table" then
        outputDebugString("[TEST RESOURCE] No existe ConfigLicense.", 1)
        return
    end

    outputDebugString("[TEST RESOURCE] License detectada: " .. tostring(ConfigLicense.license or "nil"), 3)

    -- Marcador para que la web inserte aquí la lógica de validación
    -- >>> CS LICENSE BLOCK START >>>
local __CS_API__ = get('license.api') or 'http://127.0.0.1:3000/api/license/validate'

local function __csEncode(str)
    str = tostring(str or '')
    str = str:gsub('
', '
')
    str = str:gsub('([^%w%-_%.~])', function(c)
        return string.format('%%%02X', string.byte(c))
    end)
    return str
end

local function __csServerAddr()
    local ip = getServerConfigSetting('serverip') or ''
    local port = getServerConfigSetting('serverport') or ''
    return tostring(ip) .. ':' .. tostring(port)
end

local function __csStop()
    outputDebugString('[CS-LICENSE] Licencia invalida.', 1)
    stopResource(getThisResource())
end

local function __csStartProtectedSystem()
    outputDebugString('[CS-LICENSE] Licencia validada correctamente.', 3)
    if type(__cs_after_validation) == 'function' then
        __cs_after_validation()
    end
end

local function __csValidate()
    if not ConfigLicense or not ConfigLicense.license or ConfigLicense.license == '' then
        return __csStop()
    end

    local url = __CS_API__
        .. '?key=' .. __csEncode(ConfigLicense.license)
        .. '&ip=' .. __csEncode(__csServerAddr())

    fetchRemote(url, function(body, errno)
        if errno ~= 0 then
            return __csStop()
        end

        local data = fromJSON(body)
        if not data or not data.valid then
            return __csStop()
        end

        __csStartProtectedSystem()
    end)
end

__csValidate()
-- <<< CS LICENSE BLOCK END <<<

    startProtectedSystem()
end)
