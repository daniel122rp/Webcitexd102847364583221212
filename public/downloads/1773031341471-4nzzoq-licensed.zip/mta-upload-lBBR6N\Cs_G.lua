ConfigLicense = {
    license = ""
}
